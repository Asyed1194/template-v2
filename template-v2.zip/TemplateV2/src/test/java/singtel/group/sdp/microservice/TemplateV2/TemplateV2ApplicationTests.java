package singtel.group.sdp.microservice.TemplateV2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TemplateV2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
