package singtel.group.sdp.microservice.TemplateV2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TemplateV2Application {

	public static void main(String[] args) {
		SpringApplication.run(TemplateV2Application.class, args);
	}

}
