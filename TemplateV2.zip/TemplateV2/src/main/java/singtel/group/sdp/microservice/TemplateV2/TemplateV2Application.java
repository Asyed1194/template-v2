package singtel.group.sdp.microservice.TemplateV2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

import static singtel.group.sdp.microservice.TemplateV2.JSONResponse.JSONReader.jsonGetRequest;

@SpringBootApplication
public class TemplateV2Application {

	public static void main(String[] args) {
		SpringApplication.run(TemplateV2Application.class, args);

		//Redundant
		//System.out.println(jsonGetRequest("https://jsonplaceholder.typicode.com/users"));


		RestTemplate restTemplate = new RestTemplate();
		String response = restTemplate.getForObject("https://jsonplaceholder.typicode.com/users", String.class);

		System.out.println(response);
	}}


