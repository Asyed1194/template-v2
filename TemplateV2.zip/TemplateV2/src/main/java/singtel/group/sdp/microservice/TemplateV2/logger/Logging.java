package singtel.group.sdp.microservice.TemplateV2.logger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import singtel.group.sdp.microservice.TemplateV2.controller.ProductController;

public class Logging {
    Logger logger = LoggerFactory.getLogger(ProductController.class);
}


